from app.integrations.google_calendar import create_calendar_event

event = create_calendar_event(
    summary="Vaani Test Appointment",
    start_datetime="2026-07-01T17:00:00",
)

print("Event created successfully")
print(event.get("htmlLink"))